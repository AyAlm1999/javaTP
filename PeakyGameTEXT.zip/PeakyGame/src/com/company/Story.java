package com.company;
//Classe qui permet seulement d'avoir l'histoire du jeu avec les différents actes
public class Story {
    public static void printIntro () {
        Game.clearConsole();
        Game.printSeperator(30);
        System.out.println("HISTOIRE");
        Game.printSeperator(30);
        System.out.println("Les Peaky Blinders sont un gang qui recrute aujourd'hui des personnes aux capacités surnaturelles.");
        System.out.println("Vous en êtes une. Issu(e) d'une famille de sociers et de guerriers, vous souhaitez faire vos preuves.") ;
        System.out.println("Et c'est alors que le grand Thomas Shelby vous donne une chance : éliminez ses adversaires et vous aurez votre place dans la famille !") ;
        Game.anythingToContinue();

    }

    public static void FirstActIntro () {
        Game.clearConsole();
        Game.printSeperator(30);
        System.out.println("ACTE I - INTRO");
        Game.printSeperator(30);
        System.out.println("Vous sortez du Garrison Pub avec une détermination sans faille. ");
        System.out.println("Vous allez devenir le prochain membre de cette illustre famille, quoi qu'il en coûte !");
        System.out.println("Et c'est d'un pas décidé que vous longez les rues sombres et étroites du quartier de Small Heath, à la recherche des premiers ennemis à affronter !");
        Game.anythingToContinue();

    }

    public static void FirstActOutro () {
        Game.clearConsole();
        Game.printSeperator(30);
        System.out.println("ACTE I - OUTRO");
        Game.printSeperator(30);
        System.out.println("Félicitations ! Vous l'avez fait !  ");
        System.out.println("Le quartier de Small Heath a été nettoyé de tous les ennemis des Peaky Blinders grâce à vous ! ");
        System.out.println("Vous vous sentez grandi, puissant et prêt à tout affronter désormais ! Et c'est avec cette fougue qui vous a pris que vous décidez de vous rendre à l'église catholique, là où les ennemis se cachent parmi les innocents, tels des loups dans une bergerie.");
        Game.anythingToContinue();

    }

    public static void SecondActIntro() {
        Game.clearConsole();
        Game.printSeperator(30);
        System.out.println("ACTE II - INTRO");
        Game.printSeperator(30);
        System.out.println("Vous vous tenez à présent devant l'église catholique de Birmingham, un lieu pieu où les innocents ne peuvent plus se rendre. ");
        System.out.println("L'endroit est désert, aucun bruit, pas même celui d'un corbeau, ne vient déranger l'inquiétante quiétude du lieu. ");
        System.out.println(" Vous vous aventurez à l'intérieur, les sens aux aguets.");
        Game.anythingToContinue();
    }

    public static void SecondActOutro () {
        Game.clearConsole();
        Game.printSeperator(30);
        System.out.println("ACTE II - OUTRO");
        Game.printSeperator(30);
        System.out.println("Un sourire sanglant aux lèvres, vous vous tenez victorieux au coeur de l'église !");
        System.out.println("Vos pieds vous mènent dehors et la douce caresse du soleil effleure votre peau. Vous êtes si heureux de l'avoir fait ! ");
        System.out.println("Birmingham étant à présent tranquille, c'est au tour des ennemis de Londres de subir votre courroux !");
        Game.anythingToContinue();

    }

    public static void ThirdActIntro () {
        Game.clearConsole();
        Game.printSeperator(30);
        System.out.println("ACTE III - INTRO");
        Game.printSeperator(30);
        System.out.println( "Camden Town baigne sous un halo pourpre qui vous indique une chose : la tâche ne sera pas aussi facile que précèdemment ! ");
        System.out.println("Mais vous savez que vous serez à la hauteur, que vous seriez digne d'être un Peaky Blinder !");
        System.out.println(" Vous talonnez votre cheval noir avant de galoper sur les rues pavées de Camden Town.");
        Game.anythingToContinue();
    }

    public static void ThirdActOutro () {
        Game.clearConsole();
        Game.printSeperator(30);
        System.out.println("ACTE III - OUTRO");
        Game.printSeperator(30);
        System.out.println("Vous n'avez aucune limite et aucun adversaire à votre cheville !");
        System.out.println("Vous remontez sur votre cheval, le corps certes fatigué mais l'esprit enflammé et surexcité. ");
        System.out.println("Il n'y avait plus qu'une seule étape qui vous sépare dorénavant de devenir un Peaky Blinder !");
        Game.anythingToContinue();

    }

    public static void FourthActIntro () {
        Game.clearConsole();
        Game.printSeperator(30);
        System.out.println("ACTE IV - INTRO");
        Game.printSeperator(30);
        System.out.println("La prison est la salle du trône : si vous y survivez, vous aurez la couronne.");
        System.out.println("Mais dans le cas contraire, votre sang la tachera et votre âme quittera votre corps. ");
        System.out.println("Les cellules sont vides. D'apparence seulement, car vous savez le monstre qui s'y cache et qui se repaît des pêchés des condamnés.");
        Game.anythingToContinue();

    }

    public static void printEnd (Player player) {
        Game.clearConsole();
        Game.printSeperator(30);
        System.out.println("Féliciations " + player.name + ", vous sortez vainqueur de ces épreuves ! ");
        System.out.println("Vous êtes dorénavant un Peaky Blinder, un vrai ! ");
        System.out.println("De l'ombre sort le grand Thomas Shelby, montre à gousset entre les mains, ses yeux de glace vous fixant d'un air impavide.");
        System.out.println("- Et tu n'as pas mis longtemps à tous les vaincre, je suis presque impressioné " + player.name) ;
        System.out.println("Vous le regadrez sans rien dire, le coeur battant la chamade.");
        System.out.println("- Eh bien, voilà ta couronne soldat. Et bienvenue dans la famille.");
        Game.printSeperator(30);
        System.out.println("FIN DU JEU");

    }
}
