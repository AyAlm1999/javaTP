package com.company;

public class Player extends Character {

    public int numAttacksUpgrades, numDefUpgrades;

    public String [] attackUpgrades = {"Guerrier", "Mage", "Guérisseur", "Chasseur"};
    public String [] defUpgrades = {"Esquive", "Barrière de protection", "Guérison", "Bouclier"};

    public Player (String name) {
        super (name, 100, 0);
        this.numAttacksUpgrades = 0;
        this.numDefUpgrades = 0;
        chooseChar();

    }

    @Override
    public int attack() {
        return (int) (Math.random()*(xp/4 + numAttacksUpgrades*3 + 3) + xp/10 + numAttacksUpgrades*2 + numDefUpgrades +1);
    }


    @Override
    public int defend() {
        return (int) (Math.random()*(xp/4 + numDefUpgrades*3 + 3) + xp/10 + numDefUpgrades*2 + numAttacksUpgrades +1);
    }

    public void chooseChar(){
        Game.clearConsole();
        Game.printHeading("Choisissez un personnage");
        System.out.println("(1) "+ attackUpgrades[numAttacksUpgrades] );
        System.out.println("(2) "+ defUpgrades[numDefUpgrades] );
        //récupérer choix du joueur
        int input = Game.readInt(" –>", 2);
        Game.clearConsole();
        if (input == 1){
            Game.printHeading("Vous avez choisi " + attackUpgrades[numAttacksUpgrades] + "!");
            numAttacksUpgrades++;
        }else{
            Game.printHeading("Vous avez choisi " + defUpgrades[numDefUpgrades] + "!");
            numDefUpgrades++;
        }
        Game.anythingToContinue();
    }
}
