package com.company;

public class Main {

    public static void main(String[] args) {
	// Lancer le jeu
        Game.startGame();
    }
}
