package com.company;

public abstract class Character {
    //Variables/ attributs que les personnages possèdent
    public String name;
    public int maxHp, hp, xp;

    //Constructeur pour les personnages
    public Character (String name, int maxHp, int xp){
        this.name = name;
        this.maxHp = maxHp;
        this.xp = xp;
        this.hp = maxHp;
    }

    //Méthode que chaque personnage posède
    public abstract int attack();
    public abstract int defend();
}
