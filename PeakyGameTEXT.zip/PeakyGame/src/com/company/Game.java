package com.company;

import java.util.Scanner;

public class Game {

    static Scanner scanner = new Scanner(System.in);
    static Player player ;
    public static boolean isRunning;

    //random encounters
    public static String [] encounters = {"Combat", "Combat", "Combat", "Repos", "Repos"} ;

    //nom des ennemis
    public static String[] ennemies = {"Inspecteur", "Gangster", "Mafieux", "Mafieux", "Monstre"};

    //Elements de l'histoire
    public static int place = 0, act = 1;
    public static String[] places = {"Quartier de Small Heath", "Eglise catholique", "Camden Town", "Prison de Winson Green"};

    public static int readInt(String prompt, int userChoices) {
        int input;

        do {
            System.out.println(prompt);
            try {
                input = Integer.parseInt(scanner.next());
            } catch (Exception e) {
                input = -1;
                System.out.println("Veuillez entrer un entier !");
            }

        } while (input < 1 || input > userChoices);
        return input;
    }

    //méthode pour simuler une console qui s'est effacée
    public static void clearConsole() {
        for (int i = 0; i < 100; i++)
            System.out.println();
    }

    //méthode pour afficher un séparateur avec une longueur n
    public static void printSeperator(int n) {
        for (int i = 0; i < n; i++)
            System.out.print("-");
        System.out.println();
    }

    //méthode pour afficher un titre
    public static void printHeading(String title) {
        printSeperator(30);
        System.out.println(title);
        printSeperator(30);
    }

    //méthode pour arrêter le jeu jusqu'à ce que l'utilisateur entre quelque chose
    public static void anythingToContinue() {
        System.out.println("\n Veuillez taper 1 puis Entrer pour continuer.");
        scanner.next();

    }

    //méthode pour lancer le jeu
    public static void startGame (){
        boolean nameSet = false ;
        String name;
        clearConsole();
        printSeperator(40);
        printSeperator(30);
        System.out.println("PEAKY BLINDERS : UN COMBAT MAGIQUE !");
        System.out.println("Un RPG fait par Ayah AL MUTWALY");
        printSeperator(30);
        printSeperator(40);
        anythingToContinue();

        //nom du joueur
        do {
            clearConsole();
            printHeading("Quel est votre nom ?");
            name = scanner.next();
            //vérifier le nom du joueur et donner la possibilité de changer si jamais
            clearConsole();
            printHeading("Votre nom est " + name + ".\n Est-ce bien correct ?");
            System.out.println("(1) Oui !" );
            System.out.println("(2) Non, je souhaite changer mon nom." );
            int input = readInt("–> ", 2);
            if (input == 1)
                nameSet = true ;

        }while (!nameSet);

        //Affichage de l'intro de l'histoire
        Story.printIntro();

        //création d'un nouvel objet joueur avec le nom
        player = new Player(name);

        //Pour que la boucle du jeu continue
        isRunning= true;

        //Affichage de l'intro de l'Acte I
        Story.FirstActIntro();

        //commencer la boucle principale du jeu
        gameLoop();
    }
    //méthode qui permet de changer les valeurs du jeu basé sur le xp du joueur
    public static void checkAct() {
        if (player.xp >= 10 && act ==1){
            //incrémenter act et place
            act = 2;
            place = 1;
            //histoire
            Story.FirstActOutro();
            //"level up" du joueur
            player.chooseChar();
            //histoire
            Story.SecondActIntro();
            //On assigne de nouvelles valeurs aux ennemis
            ennemies[0] = "Un gangster italien ";
            ennemies[1] = "Un mafieux";
            ennemies[2] = "Un gangster amricain";
            ennemies[3] = "Un traître";
            ennemies[4] = "Un mercenaire";
            //On assigne de nouvelles valeurs aux rencontres
            encounters[0] = "Combat";
            encounters[1] = "Combat";
            encounters[2] = "Combat";
            encounters[3] = "Combat";
            encounters[4] = "Repos";
            //On guérit complétement le joueur
            player.hp= player.maxHp;

        }else if (player.xp >= 50 && act == 2){
            //incrémenter act et place
            act = 3;
            place = 2;
            //histoire
            Story.SecondActOutro();
            //"level up" du joueur
            player.chooseChar();
            //histoire
            Story.ThirdActIntro();
            //On assigne de nouvelles valeurs aux ennemis
            ennemies[0] = "Inspecteur Campbell ";
            ennemies[1] = "Gangster Billy Kimber ";
            ennemies[2] = "Gangster Darby Sabini  ";
            ennemies[3] = "Mafieux Lucas Changretta  ";
            ennemies[4] = "Le Monstre de la prison ";
            //On assigne de nouvelles valeurs aux rencontres
            encounters[0] = "Combat";
            encounters[1] = "Repos";
            encounters[2] = "Combat";
            encounters[3] = "Combat";
            encounters[4] = "Combat";
            //On guérit complétement le joueur
            player.hp= player.maxHp;
        }else if (player.xp >= 100 && act == 3){
            //incrémenter act et place
            act = 4;
            place = 3;
            //histoire
            Story.ThirdActOutro();
            //"level up" du joueur
            player.chooseChar();
            //histoire
            Story.FourthActIntro();
            //On guérit complétement le joueur
            player.hp= player.maxHp;
            //On appelle le combat final
            //finalBattle();

        }

    }

    //méthode pour une rencontre random
    public static void randomEncounter(){
        int encounter = (int) (Math.random()* encounters.length);
        if (encounters[encounter].equals("Combat")){
            randomBattle();

        }else if (encounters[encounter].equals("Repos")){
            //takeRest();

        }else {
            //shop();

        }
    }

    //méthode pour continuer l'aventure
    public static void continueJourney() {
        checkAct();
        //Vérifier si ce n'est pas le dernier acte
        if (act!= 4)
            randomEncounter();

    }

    //Affichage des infos importantes concernant le personnage
    public static void characterInfo(){
        clearConsole();
        printHeading("INFORMATIONS PERSONNAGE");
        System.out.println(player.name + "\tHP : " + player.hp + "/" + player.maxHp);
        printSeperator(20);
        System.out.println("XP : " + player.xp);
        printSeperator(20);

        //Affichage du personnage choisi
        if (player.numAttacksUpgrades > 0) {
            System.out.println("Trait offensif : " + player.attackUpgrades[player.numAttacksUpgrades - 1]);
            printSeperator(20);
        }
        if (player.numDefUpgrades > 0){
            System.out.println("Trait défensif : " + player.defUpgrades[player.numDefUpgrades - 1]);
        }
        anythingToContinue();
    }

    //Création d'un combat random
    public static void randomBattle(){
        clearConsole();
        printHeading("Vous êtes tombé(e) sur un ennemi ! Préparez-vous à l'affronter !");
        anythingToContinue();
        //Création d'un nouvel ennemi
        battle(new Enemy(ennemies[(int) (Math.random()* ennemies.length)],player.xp ));
    }

    //Méthode combat principale
    private static void battle (Enemy enemy) {
        //boucle principale combat
        while (true) {
            clearConsole();
            printHeading(enemy.name + "\nHP : " + enemy.hp + "/" + enemy.maxHp);
            printHeading(player.name + "\nHP : " + player.hp + "/" + player.maxHp);
            System.out.println("Que souhaitez-vous faire ? ");
            printSeperator(20);
            System.out.println("(1) Me battre !\n(2) Utiliser une potion !\n(3) Fuir !");
            int input = readInt("–> ", 3);

            if (input == 1) {
                //SE BATTRE
                //On calcule les dégâts infligés aux deux
                int dmg = player.attack() - enemy.defend();
                int dmgTook = enemy.attack() - player.defend();
                //On vérifie que les dégâts ne sont pas négatifs

                if (dmgTook < 0) {
                    //on rajoute des dégâts si le joueur se défend bien
                    dmg -= dmgTook/2 ;
                    dmgTook = 0;
                }

                if (dmg < 0 ) {
                    dmg = 0;
                    player.hp -= dmgTook;
                    enemy.hp -= dmg;
                    //On affiche les infos de ce round
                    clearConsole();
                    printHeading("COMBAT");
                    System.out.println("Vous avez infligé " + dmg + " dégâts à " + enemy.name + ".");
                    printSeperator(15);
                    System.out.println("Le " + enemy.name + " vous a infligé " + dmgTook + " dégâts.");
                    anythingToContinue();
                    //On vérifie si le joueur est en vie ou non
                    if (player.hp <= 0) {
                        playerDied(); //méthode pour terminer le jeu
                        break;
                    }

                    else if (enemy.hp <= 0) {
                        //Dire au joueur qu'il a gagné
                        clearConsole();
                        printHeading("Vous avez battu le " + enemy.name + " !");
                        //On augmente le xp du joueur
                        player.xp += enemy.xp;
                        System.out.println("Vous avez gagné " + enemy.xp + " XP !");
                        anythingToContinue();
                        break;
                    }
                }
            }

            else if (input ==2) {
                //PRENDRE UNE POTION
            }

            else {
                //FUIR
                clearConsole();
                //On vérifie qu'on n'est pas dans le dernier acte (boss)
                if (act != 4 ) {
                    //35% de chance de fuir
                    if (Math.random()*10 + 1 <= 3.5) {
                        printHeading("Vous avez fui le " + enemy.name + " !");
                        anythingToContinue();
                        break;
                    }else {
                        printHeading("Vous n'avez pas réussi à fuir.");
                        //On calcule les dégâts que le joueur se voit infligé
                        int dmgTook = enemy.attack();
                        System.out.println("Dans votre fuite, vous avez reçu 0" + dmgTook + " dégâts !");
                        anythingToContinue();
                        //On vérifie si le joueur est toujours en vie
                        if (player.hp <= 0 )
                            playerDied();
                    }
                }else {
                    printHeading("VOUS NE POUVEZ PAS VOUS ÉCHAPPER !!!");
                    anythingToContinue();

                }
                }
            }


    }

    //Affichage du menu principal
    public static void printMenu(){
        clearConsole();
        printHeading(places[place]);
        System.out.println("Veuillez choisir une action");
        printSeperator(20);
        System.out.println("(1) Poursuivre l'aventure");
        System.out.println("(2) Informations sur le personnage");
        System.out.println("(3) Quitter le jeu");

    }

    //Méthode appelée lorsque le joueur est mort
    private static void playerDied () {
        clearConsole();
        printHeading("Vous êtes mort...");
        printHeading("Vous avez gagné " + player.xp + " XP lors de cette aventure. Essayez de faire mieux la prochaine fois !");
        System.out.println("Merci d'avoir joué à ce jeu, en espérant qu'il vous ait plu !");
        isRunning = false;
    }

    //Boucle principale du jeu
    public static void gameLoop() {
        while(isRunning){
            printMenu();
            int input = readInt("–> ", 3);
            if (input == 1)
                continueJourney();
            else if (input == 2)
                characterInfo();
            else isRunning = false;
            }
        }

    }


//}

