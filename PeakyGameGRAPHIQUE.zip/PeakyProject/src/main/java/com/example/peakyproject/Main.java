// *************** Projet Ayah AL MUTWALY*************//
// Partie graphique javaFX du jeu, la partie du jeu
// en tant que tel est dans un autre dossier.

package com.example.peakyproject;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {

    public static Stage stage;

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader
                (Main.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Main.stage = stage;
        stage.setTitle("Peaky Blinders RPG");
        stage.setScene(scene);
        stage.show();

    }

    public static void main(String[] args) {
        launch();
    }
}