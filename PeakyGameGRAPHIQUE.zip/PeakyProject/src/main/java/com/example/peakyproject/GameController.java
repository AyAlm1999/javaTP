package com.example.peakyproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import rpg.Game;

import java.io.IOException;

public class GameController {
    public static Stage stage;
    // Les différents boutons
    @FXML
    private Button GoBttn;

    @FXML
    private Button QuitBttn;

    @FXML
    private Button HunterBttn;

    @FXML
    private Button MageBttn;

    @FXML
    private Button HealerBttn;

    @FXML
    private Button WarriorBttn;


    @FXML
    private ImageView background;

    @FXML
    private ImageView characters;

    @FXML
    private Button fightButton;

    // "initialize()" est appelé par JavaFX à l'affichage de la fenêtre
    @FXML
    public void initialize() {

    }


    @FXML
    protected void GoBttnClicked() throws IOException {
        // Affiche la fenêtre principale du jeu
        FXMLLoader fxmlLoader = new FXMLLoader
                (Main.class.getResource("gamePlay-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Main.stage.setScene(scene);
        Main.stage.show();
    }

    private void updateFightButton() {
        switch (Game.context.status) {
            case START_COMBAT:
                fightButton.setText("Lancer le combat !");
                fightButton.setOnAction( event -> {
                    //updateListViews();
                    Game.context.startNextFighterTurn();
                    updateFightButton();
                } );
                break;
            case HERO_TURN:
                fightButton.setText("Attaque du héro...");
                fightButton.setOnAction( event -> {
                    Game.context.startHeroTurn();
                    //updateListViews();
                    Game.context.startNextFighterTurn();
                    updateFightButton();
                } );
                break;
            case ENEMY_TURN:
                fightButton.setText("Attaque de l'ennemi...");
                fightButton.setOnAction( event -> {
                    Game.context.startEnemyTurn();
                    //updateListViews();
                    Game.context.startNextFighterTurn();
                    updateFightButton();
                } );
                break;
            case END_GAME:
                fightButton.setDisable(true);
                break;
        }
    }


    //Bouton quitter qui ferme le jeu
    public void handleQuitButtonAction(ActionEvent actionEvent) {
        Stage stage = (Stage) QuitBttn.getScene().getWindow();
        stage.close();
    }
}



