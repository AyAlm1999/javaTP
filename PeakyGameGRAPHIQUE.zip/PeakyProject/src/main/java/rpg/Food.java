package rpg;

public class Food implements Consumable {
}
