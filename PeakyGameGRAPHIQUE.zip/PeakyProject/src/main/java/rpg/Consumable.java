package rpg;

public interface Consumable {
}
