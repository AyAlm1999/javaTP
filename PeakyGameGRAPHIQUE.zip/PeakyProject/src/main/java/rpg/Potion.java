package rpg;

public class Potion {
}
