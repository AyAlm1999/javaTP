package rpg;

public class Boss {
}
